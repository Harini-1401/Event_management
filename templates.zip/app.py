from flask import Flask, render_template, request, redirect, url_for, session
from flask_bcrypt import Bcrypt
import sqlite3
import os

app = Flask(__name__)
app.secret_key = "your_secret_key"
bcrypt = Bcrypt(app)

# Ensure database directory exists
DATABASE_PATH = "database/users.db"
EVENTS_DATABASE_PATH = "database/events.db"
if not os.path.exists("database"):
    os.makedirs("database")

# Initialize databases
def init_db():
    # Ensure the database folder exists
    if not os.path.exists("database"):
        os.makedirs("database")

    # Create Users and Registrations tables in users.db
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS registrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            event_id INTEGER NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (event_id) REFERENCES events(id)
        )
    ''')

    conn.commit()
    conn.close()

    # Create Events table in events.db
    conn = sqlite3.connect(EVENTS_DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            date TEXT NOT NULL,
            organizer TEXT NOT NULL
        )
    ''')
    
    conn.commit()
    conn.close()

init_db()  # Initialize databases


# Role selection for registration
user_roles = {"admin": "Admin", "organizer": "Organizer", "student": "Student"}

@app.route("/")
def home():
    return redirect(url_for("login"))

# Register User
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = bcrypt.generate_password_hash(request.form["password"]).decode("utf-8")
        role = request.form["role"]

        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        try:
            cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", (username, password, role))
            conn.commit()
        except sqlite3.IntegrityError:
            return "Username already exists!"
        finally:
            conn.close()

        return redirect(url_for("login"))
    
    return render_template("register.html", roles=user_roles)

# Login User
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone()
        conn.close()

        if user and bcrypt.check_password_hash(user[2], password):
            session["user"] = username
            session["role"] = user[3]
            return redirect(url_for("dashboard"))

        return "Invalid credentials!"

    return render_template("login.html")

# Role-Based Dashboard
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))

    role = session.get("role", "Unknown")
    
    if role == "admin":
        return redirect(url_for("admin_panel"))
    elif role == "organizer":
        return redirect(url_for("organizer_dash"))
    elif role == "student":
        return redirect(url_for("student_dash"))
    
    return "Invalid role!"

# Admin Panel
@app.route("/admin")
def admin_panel():
    if "user" not in session or session["role"] != "admin":
        return redirect(url_for("login"))

    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, role FROM users")
    users = cursor.fetchall()
    conn.close()

    conn = sqlite3.connect(EVENTS_DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events")
    events = cursor.fetchall()
    conn.close()

    return render_template("admin_panel.html", users=users, events=events)

@app.route("/delete_user/<int:user_id>")
def delete_user(user_id):
    if "user" not in session or session["role"] != "admin":
        return redirect(url_for("login"))

    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("admin_panel"))

@app.route("/delete_event/<int:event_id>")
def delete_event(event_id):
    if "user" not in session or session["role"] != "admin":
        return redirect(url_for("login"))

    conn = sqlite3.connect(EVENTS_DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM events WHERE id=?", (event_id,))
    conn.commit()
    conn.close()
    return redirect(url_for("admin_panel"))

# Organizer Dashboard
@app.route("/organizer")
def organizer_dash():
    if "user" not in session or session["role"] != "organizer":
        return redirect(url_for("login"))

    conn = sqlite3.connect(EVENTS_DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events WHERE organizer=?", (session["user"],))
    events = cursor.fetchall()
    conn.close()

    return render_template("organizer_dash.html", events=events)

@app.route("/create_event", methods=["GET", "POST"])
def create_event():
    if "user" not in session or session["role"] != "organizer":
        return redirect(url_for("login"))

    if request.method == "POST":
        title = request.form["title"]
        description = request.form["description"]
        date = request.form["date"]
        organizer = session["user"]

        conn = sqlite3.connect(EVENTS_DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO events (title, description, date, organizer) VALUES (?, ?, ?, ?)",
                       (title, description, date, organizer))
        conn.commit()
        conn.close()

        return redirect(url_for("organizer_dash"))

    return render_template("create_event.html")

@app.route("/delete_own_event/<int:event_id>")
def delete_own_event(event_id):
    if "user" not in session or session["role"] != "organizer":
        return redirect(url_for("login"))

    conn = sqlite3.connect(EVENTS_DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM events WHERE id=? AND organizer=?", (event_id, session["user"]))
    conn.commit()
    conn.close()

    return redirect(url_for("organizer_dash"))

# Student Dashboard & Event Registration
@app.route("/student")
def student_dash():
    if "user" not in session or session["role"] != "student":
        return redirect(url_for("login"))

    conn = sqlite3.connect(EVENTS_DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events")
    events = cursor.fetchall()
    conn.close()

    return render_template("student_dash.html", events=events)

@app.route("/register_event/<int:event_id>")
def register_event(event_id):
    if "user" not in session or session["role"] != "student":
        return redirect(url_for("login"))

    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Get the user ID for the currently logged-in user
    cursor.execute("SELECT id FROM users WHERE username = ?", (session["user"],))
    user = cursor.fetchone()

    if user:
        user_id = user[0]
        cursor.execute("INSERT INTO registrations (event_id, user_id) VALUES (?, ?)", (event_id, user_id))
        conn.commit()

    conn.close()
    return redirect(url_for("student_dash"))

@app.route("/view_registrations/<int:event_id>")
def view_registrations(event_id):
    if "user" not in session or session["role"] != "organizer":
        return redirect(url_for("login"))

    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()

    # Fetch students who registered for the given event
    cursor.execute("""
        SELECT users.username 
        FROM registrations
        JOIN users ON registrations.user_id = users.id
        WHERE registrations.event_id = ?
    """, (event_id,))

    registrations = cursor.fetchall()
    conn.close()

    return render_template("view_registrations.html", registrations=registrations, event_id=event_id)
    


# Logout
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)


